<footer>
        <div class="footer-area">
                <p>©<?php echo date("Y");?> |TCLOneClick | Developed By <a href="#">TCLHQ</a></p>
        </div>
</footer>