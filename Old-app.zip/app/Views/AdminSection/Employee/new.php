<?= $this->extend('admin/layout/topHeader') ?>
<?= $this->section('title') ?> TCL | Add New Employee <?= $this->endSection() ?>
<?= $this->section('content') ?>
<?= $this->include('admin/layout/header.php');?>
<?= $this->include('admin/layout/navigation.php');?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <form action="#" method="get" class="sidebar-form search-box pull-right hidden-md hidden-lg hidden-sm">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                        <button type="submit" name="search" id="search-btn" class="btn"><i
                                class="fa fa-search"></i></button>
                    </span>
                </div>
            </form>
            <h1>Human Resources</h1>
            <small>Employee Registration</small>
            <ol class="breadcrumb hidden-xs">
                <li><a href="index-2.html"><i class="pe-7s-home"></i> Home</a></li>
                <li class="active">Admin Section</li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- Form controls -->
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="btn-group">
                            <a class="btn btn-primary btn-list" href="<?=site_url('admin/AdminSection/showEmployee')?>">
                                <i class="fa fa-list"></i> employee list</a>
                        </div>
                    </div>
                    <div class="panel-body bg-warning">
                        <form action="<?php echo base_url('admin/adminsection/create') ?>" method="post">
                            <?= csrf_field() ?>
                            <div class="">

                                <div class="col-12 mt-5">
                                    <?= $this->include('admin/includes/headerMessage.php') ?>
                                    <p class="text-muted font-14 mb-4">Please fill up the form in order to add employee
                                        records</p>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Employee PNo</label>
                                        <input class="form-control" name="per_no" type="number" autocomplete="off"
                                            required id="per_no" onBlur="checkAvailabilityEmpid()">
                                    </div>


                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">First Name</label>
                                        <input type="text" class="form-control" autocomplete="off" id="fname"
                                            name="first_name" placeholder="Enter First Name">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Middle Name</label>
                                        <input class="form-control" name="middle_name" type="text" autocomplete="off"
                                            required id="example-text-input">
                                    </div>
                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Last Name</label>
                                        <input class="form-control" name="last_name" type="text" autocomplete="off"
                                            required id="example-text-input">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-email-input" class="col-form-label">Email</label>
                                        <input class="form-control" name="email" type="email" autocomplete="off"
                                            required id="example-email-input">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label class="col-form-label">Preferred Department</label>
                                        <select class="form-control" name="department" autocomplete="off">
                                        </select>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label class="form-label">Designation</label>
                                        <select class="form-control" name="Designation" autocomplete="off">
                                            <option value="">Choose..</option>
                                            <option value="AWM">AWM</option>
                                            <option value="WM">WM</option>
                                            <option value="Chargeman">ChargeMan</option>
                                            <option value="Other">other</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-4 form-group">
                                        <label class="col-form-label">Basic Pay</label>
                                        <select class="form-control" name="basic_pay" autocomplete="off">
                                            <option value=""> - Select Level -</option>
                                            <option value="1">Level (1) - PB-1 (5200-20200) G.P. 1800</option>
                                            <option value="2">Level (2) - PB-1 (5200-20200) G.P. 1900</option>
                                            <option value="3">Level (3) - PB-1 (5200-20200) G.P. 2000</option>
                                            <option value="4">Level (4) - PB-1 (5200-20200) G.P. 2400</option>
                                            <option value="5">Level (5) - PB-1 (5200-20200) G.P. 2800</option>
                                            <option value="6">Level (6) - PB-2 (9300-34800) G.P. 4200</option>
                                            <option value="7">Level (7) - PB-2 (9300-34800) G.P. 4600</option>
                                            <option value="8">Level (8) - PB-2 (9300-34800) G.P. 4800</option>
                                            <option value="9">Level (9) - PB-2 (9300-34800) G.P. 5400</option>
                                            <option value="10">Level (10) - PB-3 (15600-39100) G.P. 5400</option>
                                            <option value="11">Level (11) - PB-3 (15600-39100) G.P. 6600</option>
                                            <option value="12">Level (12) - PB-3 (15600-39100) G.P. 7600</option>
                                            <option value="13">Level (13) - PB-4 (37400-67000) G.P. 8700</option>
                                            <option value="14">Level (13) - PB-4 (37400-67000) G.P. 8900</option>
                                            <option value="15">Level (14) - PB-4 (37400-67000) G.P. 10000</option>
                                            <option value="16">Level (15) - 67000-79000</option>
                                            <option value="17">Level (16) - 75000-80000</option>
                                            <option value="18">Level (17) - 80000</option>
                                            <option value="19">Level (18) - 90000</option>
                                        </select>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label class="col-form-label">Categoery</label>
                                        <select class="form-control" name="category" autocomplete="off">
                                            <option value="">Choose..</option>

                                            <option value="Male">Gen</option>
                                            <option value="Female">Sc</option>
                                            <option value="Other">St</option>
                                            <option value="Other">Obc</option>
                                        </select>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label class="col-form-label">Gender</label>
                                        <select class="form-control" name="gender" autocomplete="off">
                                            <option value="">Choose..</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-date-input" class="col-form-label">D.O.B</label>
                                        <input class="form-control" type="date" name="dob" id="birthdate">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Contact Number</label>
                                        <input class="form-control" name="contact" type="tel" maxlength="10"
                                            autocomplete="off" required>
                                    </div>


                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Country</label>
                                        <input class="form-control" name="country" type="text" autocomplete="off"
                                            required id="example-text-input">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Address</label>
                                        <input class="form-control" name="address" type="text" autocomplete="off"
                                            required>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">City</label>
                                        <input class="form-control" name="city" type="text" autocomplete="off" required>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-date-input" class="col-form-label">D.O.A</label>
                                        <input class="form-control" type="date" name="doj" id="doa">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-date-input" class="col-form-label">D.O.R</label>
                                        <input class="form-control" type="date" name="d_of_retirment" id="dor">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-date-input" class="col-form-label">D.O.I</label>
                                        <input class="form-control" type="date" name="d_of_retirment" id="dor">
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Acc. Number</label>
                                        <input class="form-control" name="bank_account" type="text" autocomplete="off"
                                            required>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Bank Name </label>
                                        <input class="form-control" name="bank_name" type="text" autocomplete="off"
                                            required>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Bank IFSC Code </label>
                                        <input class="form-control" name="bank_ifsc" type="text" autocomplete="off"
                                            required>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Gpf/NPS No </label>
                                        <input class="form-control" name="gpfno" type="text" autocomplete="off"
                                            required>
                                    </div>

                                    <div>
                                        <h3>Set Password for Employee Login</h3>
                                        <hr>
                                    </div>
                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Password</label>
                                        <input class="form-control" name="password" type="password" autocomplete="off"
                                            required>
                                    </div>

                                    <div class="col-sm-4 form-group">
                                        <label for="example-text-input" class="col-form-label">Confirmation
                                            Password</label>
                                        <input class="form-control" name="confirmpassword" type="password"
                                            autocomplete="off" required>
                                    </div>
                                    <div class="col-sm-4  align-middle">
                                        <button class="btn btn-primary  " name="add" id="add" type="submit"
                                            onclick="return valid();">PROCEED</button>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->
<?=$this->include('admin/layout/footer.php');?>

<?= $this->endsection() ?>