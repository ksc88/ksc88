<?= $this->extend('admin/layout/topHeader') ?>
<?= $this->section('title') ?> Pending leave <?= $this->endSection() ?>
<?= $this->section('content') ?>
<?= $this->include('admin/layout/header.php');?>
<?= $this->include('admin/layout/navigation.php');?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-box1"></i>
        </div>
        <div class="header-title">
            <form action="#" method="get" class="sidebar-form search-box pull-right hidden-md hidden-lg hidden-sm">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Search...">
                    <span class="input-group-btn">
                        <button type="submit" name="search" id="search-btn" class="btn"><i
                                class="fa fa-search"></i></button>
                    </span>
                </div>
            </form>
            <h1>Pending Leaves</h1>

            <ol class="breadcrumb hidden-xs">
                <li><a href="index.html"><i class="pe-7s-home"></i> Home</a></li>
                <li class="active">Dashboard</li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="btn-group">
                            <a class="btn btn-success" href="<?=site_url('admin/AdminSection/create') ?>"> <i
                                    class="fa fa-plus"></i> #### </a>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">

                            <div class="table-responsive">
                                <table class="table table-striped table-hover table-bordered" id="editable-sample">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>#</th>
                                            <th>RefrenceId</th>
                                            <th>From Date</th>
                                            <th>To Date</th>
                                            <th>Date OF Apply</th>
                                            <th>Approve</th>
                                        </tr>
                                    </thead>
                                    <tbody><?php $count = 1;  foreach ($data as $data) :?>
                                        <tr>
                                            <td><?= esc($count)?></td>
                                            <td><?= esc($data['referenceId'])?></td>
                                            <td><?= esc($data['fromDate'])?></td>
                                            <td><?= esc($data['toDate'])?></td>
                                            <td><?= esc($data['postingDate'])?></td>
                                          
                                            <td><a href="#"><i class="fa fa-edit" style="color:green"></i></a>
                                                <?php if( $data['status']==1) {?><a
                                                    href="<?php echo base_url()?>/updateEmpStatus/<?php echo $data['referenceId'];?>/<?php echo $sts=0;?> "
                                                    onclick="return confirm('Are you sure you want to inactive this employee?');"><i
                                                        class="fa fa-times-circle" style="color:red"></i></a>
                                                <?php } else {?>
                                                <a href="<?php echo base_url()?>/updateEmpStatus/<?php echo $data['referenceId'];?>/<?php echo $sts=1;?>"
                                                    onclick="return confirm('Are you sure you want to Activate this employee?');"><i
                                                        class="fa fa-check" style="color:green"></i></a> <?php } ?>
                                            </td>
                                        </tr>
                                        <?php   $count++;  endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
    </section> <!-- /.content -->

</div>

</div>
</div>

</div> <!-- /.content-wrapper -->

<?=$this->include('admin/layout/footer.php');?>
<?= $this->endsection() ?>