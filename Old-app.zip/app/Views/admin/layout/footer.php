<footer class="main-footer text-center">
    <strong>Copyright &copy; <script>document.write(new Date().getFullYear())</script> <a href="#">TCLHQ | IT WING</a>.</strong> All rights reserved.
</footer>
</div> 


 <!-- login area end -->
<!-- jquery latest version -->
<script src="<?php echo base_URL();?>/public/assets/js/vendor/jquery-2.2.4.min.js"></script> 
<!-- bootstrap 4 js -->
<script src="<?php echo base_URL();?>/public/assets/js/popper.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/metisMenu.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/jquery.slicknav.min.js"></script>



<!-- others plugins -->
<script src="<?php echo base_URL();?>/public/assets/js/plugins.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/scripts.js"></script>


<script type="text/javascript" src="<?php echo base_URL();?>/public/assets/table/jquery.dataTables.js"></script>
        <script type="text/javascript" src="<?php echo base_URL();?>/public/assets/table/DT_bootstrap.js"></script>
        <script src="<?php echo base_URL();?>/public/assets/table/scripts.js"></script>
        <script src="<?php echo base_URL();?>/public/assets/table/table-editable.js"></script>
        <script>
            jQuery(document).ready(function() {
                EditableTable.init();
            });
        </script>
</body>




</html>
