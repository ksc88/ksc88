<?php
namespace currencyFormat\Exception;

/**
 * NTWIndiaInvalidNumber
 *
 * Exception raised within the NTWIndia class when number is greater than acceptable value
 */
class currencyFormatNumberOverflow extends \Exception {

}
