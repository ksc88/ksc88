<?php
namespace currencyFormat\Exception;

/**
 * NTWIndiaInvalidNumber
 *
 * Exception raised within the NTWIndia class when invalid number is passed
 */
class currencyFormatInvalidNumber extends \Exception {

}
