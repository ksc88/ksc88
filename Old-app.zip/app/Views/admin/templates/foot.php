<!-- login area end -->
<!-- jquery latest version -->
<script src="<?php echo base_URL();?>/public/assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="<?php echo base_URL();?>/public/assets/js/popper.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/metisMenu.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/jquery.slicknav.min.js"></script>
<!-- others plugins -->
<script src="<?php echo base_URL();?>/public/assets/js/plugins.js"></script>
<script src="<?php echo base_URL();?>/public/assets/js/scripts.js"></script>
</body>

</html>