<div class="user-profile pull-right">
         <img class="avatar user-thumb" src="<?= base_url('/public/assets/images/avtar2.png')?>" alt="avatar">
        <h4 class="user-name dropdown-toggle" data-toggle="dropdown"> <i class="fa fa-angle-down"></i></h4>
         <div class="dropdown-menu">
            <a class="dropdown-item" href="my-profile.php">View Profile</a>
            <a class="dropdown-item" href="change-password-employee.php">Password</a>
            <a class="dropdown-item" href="<?php echo site_url('/logout') ?>">Log Out</a>
        
     </div>
</div>