<?php 
namespace App\Controllers\Admin;
use \App\Models\LeaveModel;
class AdminSection extends \App\Controllers\BaseController{
    public function index(){
        return view('AdminSection/Dashboard/dashboard',
        ['page'=>'admin'],
    );
    }

    public function create()
    {
        $model = model(Admin::class);
        if ($this->request->getMethod() === 'post') {             
           if($model->save($_POST)) {
            $rules=[
                'per_no'=>'required|min_length[3]',
                'password'=>'required|min_length[6]',
                'confirmpassword'=>'required|matches[password]',
            ];
            if(! $this->validate($rules)){
                $data['validation']=$this->validator;
                $data['page']='admin';

                return view('AdminSection/employee/new',$data );
            }
            return redirect()->to('admin/AdminSection/create')
                             ->with('info','Emp Record Interted Successfully'); 
                            }
            else{
                return redirect()->back()
                ->with('errors',$model->errors())
                ->with('warning','Invalid Data')
                ->withInput();
                 }        
        } 
        return view('AdminSection/employee/new',['page'=>'admin']);
     }

     public function showEmployee()
     {   
         $model = model(Admin::class);
         $data['data'] = $model->getEmployee();
         $data['page']='admin';
         return view('AdminSection/employee/show',$data);
     }
     public function pendingLeaves()
     {   
         $model=new LeaveModel;
         $data['page']='admin';
         $data['data'] = $model->where('status','pending')->findAll();
         return view('AdminSection/Approval/pendingLeaves',$data);
     }
}
    
    